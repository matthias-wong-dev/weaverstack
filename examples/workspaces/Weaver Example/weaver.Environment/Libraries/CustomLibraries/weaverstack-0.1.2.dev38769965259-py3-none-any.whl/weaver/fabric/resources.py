"""Resolving Fabric workspace items by name.

Item names are unique within a workspace, which is the whole reason level three
needs no configuration. This is where that assumption meets the API.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from ..errors import CommandError
from .client import FabricClient, FabricError

LAKEHOUSE = "Lakehouse"
WAREHOUSE = "Warehouse"
ENVIRONMENT = "Environment"
NOTEBOOK = "Notebook"
SQL_ENDPOINT = "SQLEndpoint"

#: A Lakehouse grows a SQLEndpoint sibling of the same name, a little after it
#: is created. That is a facet of the Lakehouse rather than an item anyone
#: addresses, so it is ignored when a name is resolved without a type — item
#: names are unique per type, not across types.
FACET_TYPES = frozenset({SQL_ENDPOINT})


class ItemNotFoundError(CommandError):
    """Raised when an item lookup returns no match."""


@dataclass(frozen=True)
class Workspace:
    id: str
    name: str

    def __str__(self) -> str:
        return f"{self.name} ({self.id})"


@dataclass(frozen=True)
class Item:
    """One workspace item — a Lakehouse, a Warehouse, an Environment."""

    id: str
    name: str
    type: str
    workspace_id: str

    def __str__(self) -> str:
        return f"{self.type} {self.name} ({self.id})"


def find_workspace(name: str, *, client: FabricClient | None = None) -> Workspace:
    """The workspace with this name."""

    client = client or FabricClient()
    matches = [
        workspace
        for workspace in client.paged("workspaces")
        if workspace.get("displayName") == name
    ]
    if not matches:
        available = ", ".join(
            sorted(w.get("displayName", "?") for w in client.paged("workspaces"))
        )
        raise CommandError(
            f"no workspace named {name!r} — found: {available or 'none'}"
        )
    if len(matches) > 1:
        raise CommandError(f"more than one workspace named {name!r}")
    return Workspace(id=matches[0]["id"], name=name)


def list_items(
    workspace: Workspace, *, item_type: str | None = None, client: FabricClient | None = None
) -> tuple[Item, ...]:
    client = client or FabricClient()
    path = f"workspaces/{workspace.id}/items"
    if item_type:
        path += f"?type={item_type}"
    return tuple(
        Item(
            id=item["id"],
            name=item.get("displayName", ""),
            type=item.get("type", ""),
            workspace_id=workspace.id,
        )
        for item in client.paged(path)
    )


def find_item(
    workspace: Workspace,
    name: str,
    *,
    item_type: str | None = None,
    client: FabricClient | None = None,
) -> Item:
    """The item with this name, which is unique within a workspace."""

    matches = [
        item
        for item in list_items(workspace, item_type=item_type, client=client)
        if item.name == name and (item_type is None or item.type == item_type)
    ]
    if item_type is None and len(matches) > 1:
        matches = [item for item in matches if item.type not in FACET_TYPES] or matches
    if not matches:
        raise ItemNotFoundError(
            f"no {item_type or 'item'} named {name!r} in workspace {workspace.name!r}"
        )
    if len(matches) > 1:
        found = ", ".join(sorted(item.type for item in matches))
        raise CommandError(
            f"more than one item named {name!r} in {workspace.name!r} ({found}) — "
            "say which type is meant"
        )
    return matches[0]


def create_lakehouse(
    workspace: Workspace, name: str, *, client: FabricClient | None = None
) -> Item:
    """Create a **schema-enabled** Lakehouse. Returns the existing one if the name is taken.

    Schemas are not optional and so are not a parameter. Weaver's catalogue lives
    in a schema called ``_``, and a Lakehouse created without schema support
    cannot hold one — so a Weaver Lakehouse made without ``enableSchemas`` is
    unusable, and a destination made without it puts managed tables somewhere
    other than ``Tables/<schema>/<table>``, which is the layout every resolved
    location assumes. There is no Weaver use for a Lakehouse that has neither.

    Fabric decides this only at creation, so getting it wrong means deleting the
    item and making it again.
    """

    client = client or FabricClient()
    try:
        return find_item(workspace, name, item_type=LAKEHOUSE, client=client)
    except CommandError:
        pass

    # Fabric holds a deleted item's name for some minutes and answers 409
    # ItemDisplayNameNotAvailableYet until it is free again.
    response = client.request(
        "POST",
        f"workspaces/{workspace.id}/lakehouses",
        payload={"displayName": name, "creationPayload": {"enableSchemas": True}},
        expected=(200, 201, 202, 409),
    )
    if response.status_code == 409:
        raise CommandError(
            f"cannot create Lakehouse {name!r} in {workspace.name!r}: "
            + (response.json().get("message") or response.text.strip()[:200])
        )
    if response.status_code == 202:
        # Long-running create: the item exists once the operation settles.
        return _await_item(workspace, name, LAKEHOUSE, client=client)
    body = response.json()
    return Item(id=body["id"], name=name, type=LAKEHOUSE, workspace_id=workspace.id)


def create_warehouse(
    workspace: Workspace, name: str, *, client: FabricClient | None = None
) -> Item:
    """Create a disposable Warehouse, returning an existing typed match."""

    client = client or FabricClient()
    try:
        return find_item(workspace, name, item_type=WAREHOUSE, client=client)
    except ItemNotFoundError:
        pass

    response = client.request(
        "POST",
        f"workspaces/{workspace.id}/warehouses",
        payload={"displayName": name},
        expected=(200, 201, 202, 409),
    )
    if response.status_code == 409:
        raise CommandError(
            f"cannot create Warehouse {name!r} in {workspace.name!r}: "
            + (response.json().get("message") or response.text.strip()[:200])
        )
    if response.status_code == 202:
        return _await_item(workspace, name, WAREHOUSE, client=client)
    body = response.json()
    return Item(id=body["id"], name=name, type=WAREHOUSE, workspace_id=workspace.id)


def delete_item(item: Item, *, client: FabricClient | None = None) -> None:
    client = client or FabricClient()
    client.request(
        "DELETE",
        f"workspaces/{item.workspace_id}/items/{item.id}",
        expected=(200, 202, 204),
    )


def refresh_sql_endpoint_metadata(
    endpoint: Item, *, client: FabricClient | None = None
) -> dict:
    """Refresh every table in one SQL analytics endpoint and await completion."""

    if endpoint.type != SQL_ENDPOINT:
        raise CommandError(
            f"SQL endpoint refresh needs a {SQL_ENDPOINT} item, got {endpoint.type!r}"
        )
    client = client or FabricClient()
    response = client.request(
        "POST",
        f"workspaces/{endpoint.workspace_id}/sqlEndpoints/{endpoint.id}/refreshMetadata",
        payload={"recreateTables": False},
        expected=(200, 202),
    )
    result = client.wait_for_operation(response)
    return {
        "lakehouse": endpoint.name,
        "sql_endpoint_id": endpoint.id,
        "operation_id": response.headers.get("x-ms-operation-id"),
        "status": result.get("status", "Succeeded"),
    }


def _await_item(
    workspace: Workspace,
    name: str,
    item_type: str,
    *,
    client: FabricClient,
    attempts: int = 30,
    pause: float = 2.0,
) -> Item:
    import time

    for _ in range(attempts):
        try:
            return find_item(workspace, name, item_type=item_type, client=client)
        except CommandError:
            time.sleep(pause)
    raise FabricError(
        f"{item_type} {name!r} did not appear in {workspace.name!r} after "
        f"{int(attempts * pause)}s"
    )
